# sp-editor

### 视频插入功能

`于2024-7-20日v1.4.4版本更新视频插入功能（属实是鸽🕊了太久了）`

- 实现方案：先以图片占位，在导出时，将携带视频链接的图片转换成视频标签。
- 更多请参考示例一
- 如果该插件有帮助到您，还望能点赞好评一下，谢谢！🌟

### 文档迁移

> 防止文档失效，提供下列五个地址，内容一致

- [地址一](https://sonvee.github.io/sv-app-docs/docs-github/src/plugins/sp-editor/sp-editor.html)
- [地址二](https://sv-app-docs.pages.dev/src/plugins/sp-editor/sp-editor.html)
- [地址三](https://sv-app-docs.4everland.app/src/plugins/sp-editor/sp-editor.html)
- [地址四](https://sv-app-docs.vercel.app/src/plugins/sp-editor/sp-editor.html) (需要梯子)
- [地址五](https://static-mp-74bfcbac-6ba6-4f39-8513-8831390ff75a.next.bspapp.com/docs-uni/src/plugins/sp-editor/sp-editor.html) (有IP限制)
