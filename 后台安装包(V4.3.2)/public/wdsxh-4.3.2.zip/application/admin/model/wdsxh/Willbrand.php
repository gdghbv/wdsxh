<?php

namespace app\admin\model\wdsxh;

use think\Model;


class Willbrand extends Model
{
    protected $name = 'wdsxh_willbrand';
}
