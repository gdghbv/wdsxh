<?php

return [
    'Image'         => '背景图片',
    'FontColor'         => '字体颜色',
    'Black'         => '黑色',
    'White'         => '白色',
    'Status normal' => '显示',
    'Set status to normal'=> '设为显示',
    'Status hidden' => '隐藏',
    'Set status to hidden'=> '设为隐藏',
    'Weigh'         => '排序',
    'Createtime'    => '创建时间',
    'Updatetime'    => '更新时间',
    'Deletetime'    => '删除时间'
];
