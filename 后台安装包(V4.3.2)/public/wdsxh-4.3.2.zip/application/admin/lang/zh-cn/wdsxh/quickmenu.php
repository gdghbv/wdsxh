<?php

return [
    'Id'          => 'ID',
    'Name'        => '名称',
    'Icon'        => '图标',
    'Skip_type'   => '跳转类型',
    'Skip_type 1' => '内部页面',
    'Skip_type 2' => '图文',
    'Skip_type 3' => '小程序',
    'Skip_type 4' => '外部链接',
    'Content'     => '内容',
    'Weigh'       => '排序',
    'Status'      => '状态',
    'Status 0'    => '禁用',
    'Set status to 0'=> '设为禁用',
    'Status 1'    => '启用',
    'Set status to 1'=> '设为启用',
    'Createtime'  => '创建时间',
    'Are you sure you want to delete this item?'            => '警告：一旦删除，数据无法恢复，谨慎处理！！！',
];
