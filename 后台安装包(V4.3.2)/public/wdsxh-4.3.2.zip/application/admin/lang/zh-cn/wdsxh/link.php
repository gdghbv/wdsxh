<?php

return [
    'Id'       => 'ID',
    'Name'     => '名称',
    'Url'      => '地址',
    'Status'   => '状态',
    'Status 0' => '停用',
    'Set status to 0'=> '设为停用',
    'Status 1' => '启用',
    'Set status to 1'=> '设为启用',
    'Weigh'    => '排序',
    'Are you sure you want to delete this item?'            => '警告：一旦删除，数据无法恢复，谨慎处理！！！',
];
