<?php

return [
    'Member_id'     => '会员名称',
    'Wdsxh_user_id' => '用户id',
    'Name'          => '名称',
    'Number'        => '编号',
    'Image'         => '证书',
    'Channel'       => '渠道',
    'Channel 1'     => '后台添加',
    'Channel 2'     => '入会申请',
    'Createtime'    => '创建时间',
    'Updatetime'    => '更新时间',
    'Are you sure you want to delete this item?'            => '警告：一旦删除，数据无法恢复，谨慎处理！！！',
];
