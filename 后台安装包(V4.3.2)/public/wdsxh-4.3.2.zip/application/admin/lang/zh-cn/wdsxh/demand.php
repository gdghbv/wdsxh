<?php

return [
    'Wdsxh_user_id'  => '用户昵称',
    'Title'          => '标题',
    'Content'        => '内容',
    'Image'          => '图片',
    'Is_anonymity'   => '是否匿名',
    'Is_anonymity 1' => '是',
    'Is_anonymity 2' => '否',
    'Createtime'     => '创建时间',
    'Updatetime'     => '更新时间',
    'Deletetime'     => '删除时间',
    'Are you sure you want to delete this item?'            => '警告：一旦删除，数据无法恢复，谨慎处理！！！',
    'Status'   => '状态',
    'Status 1' => '已处理',
    'Status 2' => '待处理',
    'Processing_time'     => '处理时间',
];
