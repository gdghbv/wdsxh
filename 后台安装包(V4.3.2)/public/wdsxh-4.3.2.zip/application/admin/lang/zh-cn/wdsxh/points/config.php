<?php

return [
    'Source'   => '积分来源',
    'Source 1' => '参加活动',
    'Source 2' => '购买商品(待上线)',
    'Source 3' => '发布供需(待上线)'
];
