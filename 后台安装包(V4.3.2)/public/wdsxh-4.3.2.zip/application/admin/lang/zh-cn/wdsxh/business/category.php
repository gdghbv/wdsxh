<?php

return [
    'Name'          => '名称',
    'Createtime'    => '创建时间',
    'Updatetime'    => '更新时间',
    'Deletetime'    => '删除时间',
    'Weigh'         => '权重',
    'Status'        => '状态',
    'Status normal' => '显示',
    'Set status to normal'=> '设为显示',
    'Status hidden' => '隐藏',
    'Set status to hidden'=> '设为隐藏',
    'Are you sure you want to delete this item?'            => '警告：一旦删除，数据无法恢复，谨慎处理！！！',
];
