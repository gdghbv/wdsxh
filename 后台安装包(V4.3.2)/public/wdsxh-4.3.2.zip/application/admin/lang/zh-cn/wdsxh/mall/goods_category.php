<?php

return [
    'Image'      => '图片',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Deletetime' => '删除时间',
    'Weigh'      => '权重',
    'Status'     => '状态',
    'Status 0'   => '隐藏',
    'Set status to 0'=> '设为隐藏',
    'Status 1'   => '显示',
    'Set status to 1'=> '设为显示',
    'Are you sure you want to delete this item?'            => '警告：一旦删除，数据无法恢复，谨慎处理！！！',
    'Pid'=> '父级分类',
];
