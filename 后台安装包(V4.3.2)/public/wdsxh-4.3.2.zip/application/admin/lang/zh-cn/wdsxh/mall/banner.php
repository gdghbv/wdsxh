<?php

return [
    'Id'          => 'ID',
    'Title'       => '轮播标题',
    'Image'       => '轮播图片',
    'Jump_type'   => '跳转类型',
    'Jump_type 1' => '图文',
    'Jump_type 2' => '内部页面',
    'Jump_type 4' => '小程序',
    'Jump_type 3' => '外部链接',
    'Content'     => '图文内容',
    'Jump_link'   => '跳转链接',
    'Status'      => '状态',
    'Status 0'    => '禁用',
    'Set status to 0'=> '设为禁用',
    'Status 1'    => '启用',
    'Set status to 1'=> '设为启用',
    'Createtime'  => '创建时间',
    'Updatetime'  => '更新时间',
    'Deletetime'  => '删除时间',
    'Weigh'       => '权重',
    'Are you sure you want to delete this item?'            => '警告：一旦删除，数据无法恢复，谨慎处理！！！',
];
