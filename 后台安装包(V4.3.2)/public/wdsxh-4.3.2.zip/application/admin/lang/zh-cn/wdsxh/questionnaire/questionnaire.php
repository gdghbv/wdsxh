<?php
// +----------------------------------------------------------------------
// | 麦沃德科技赋能开发者，助力商协会发展 
// +----------------------------------------------------------------------
// | Copyright (c) 2017～2024  www.wdsxh.cn    All rights reserved.
// +----------------------------------------------------------------------
// | 沃德商协会系统并不是自由软件，不加密，并不代表开源，未经许可不可自由转售和商用
// +----------------------------------------------------------------------
// | Author: MY WORLD Team <bd@maiwd.cn>   www.maiwd.cn
// +----------------------------------------------------------------------

return [
    'Title'         => '标题',
    'End_time'      => '结束时间',
    'Member_id'     => '发布人',
    'Wechat_id'     => '用户名称',
    'Createtime'    => '创建时间',
    'Updatetime'    => '更新时间',
    'Deletetime'    => '删除时间',
    'Weigh'         => '权重',
    'Status'        => '状态',
    'Status normal' => '显示',
    'Set status to normal'=> '设为显示',
    'Status hidden' => '隐藏',
    'Set status to hidden'=> '设为隐藏',
    'Page_view'     => '浏览量',
    'Are you sure you want to delete this item?'            => '警告：一旦删除，数据无法恢复，谨慎处理！！！',
    'Applet_questionnaire_qrcode_path'             => '问卷调查小程序码',
    'Non_member_answer_sheet_status'               => '非会员答卷状态',
    'Non_member_answer_sheet_status 1'             => '可以答卷',
    'Non_member_answer_sheet_status 2'             => '不能答卷',
];
