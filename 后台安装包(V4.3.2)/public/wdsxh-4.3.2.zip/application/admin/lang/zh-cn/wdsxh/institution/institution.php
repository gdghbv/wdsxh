<?php

return [
    'Name'         => '机构名称',
    'Icon'         => '机构图标',
    'Images'       => '轮播图片',
    'Introduction' => '机构简介',
    'Status'       => '状态',
    'Status 0'     => '禁用',
    'Set status to 0'=> '设为禁用',
    'Status 1'     => '启用',
    'Set status to 1'=> '设为启用',
    'Weigh'        => '排序',
    'Createtime'   => '创建时间',
    'Updatetime'   => '更新时间'
];
