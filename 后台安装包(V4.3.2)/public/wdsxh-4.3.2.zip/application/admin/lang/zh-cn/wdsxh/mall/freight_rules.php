<?php

return [
    'Min'           => '订单最小金额',
    'Max'           => '订单最大金额',
    'Price'         => '价格(元)',
    'Createtime'    => '创建时间',
    'Updatetime'    => '更新时间',
    'Deletetime'    => '删除时间',
    'Status'        => '状态',
    'Status normal' => '正常',
    'Set status to normal'=> '设为正常',
    'Status hidden' => '隐藏',
    'Set status to hidden'=> '设为隐藏',
    'Are you sure you want to delete this item?'            => '警告：一旦删除，数据无法恢复，谨慎处理！！！',
    'Open_area'           => '区域(多选)',
];
