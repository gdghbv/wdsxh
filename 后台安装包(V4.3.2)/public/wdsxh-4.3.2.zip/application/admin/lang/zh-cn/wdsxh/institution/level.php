<?php

return [
    'Institution_id'           => '机构名称',
    'Level_name'               => '级别名称',
    'Createtime'               => '创建时间',
    'Updatetime'               => '更新时间',
    'Institution.name'         => '机构名称',
    'Institution.icon'         => '机构图标',
    'Institution.images'       => '轮播图片',
    'Institution.introduction' => '机构简介',
    'Institution.status'       => '状态',
    'Institution.status 0'     => '禁用',
    'Institution.status 1'     => '启用',
    'Institution.weigh'        => '排序',
    'Institution.createtime'   => '创建时间',
    'Institution.updatetime'   => '更新时间'
];
