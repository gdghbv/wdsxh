<?php

return [
    'Name'              => '商协名称',
    'Logo'              => '商会logo',
    'Contacts'          => '联系人',
    'Phone'             => '电话',
    'Mailbox'           => '邮箱',
    'Address'           => '地址',
    'Wananchi_qr_code'  => '公众号二维码',
    'Qr_code_jump_link' => '二维码跳转链接',
    'Rules'             => '商协章程',
    'Honor'             => '商协荣誉',
    'Notice'            => '入会须知',
    'Course'            => '商协介绍',
    'Createtime'        => '创建时间',
    'Updatetime'        => '更新时间',
    'Bank_account_name'             => '开户名称',
    'Receiving_account'             => '收款账号',
    'Bank_name'            => '银行名称',
];
