<?php

return [
    'Wechat_id'   => '微信用户ID',
    'Points'      => '变更积分',
    'Before'      => '变更前积分',
    'After'       => '变更后积分',
    'Memo'        => '备注',
    'Createtime'  => '添加时间',
    'Change'      => '变更类型',
    'Change 1'    => '增加',
    'Change 2'    => '减少',
    'Activity_id' => '活动ID',
    'Source'   => '积分来源',
    'Source 1' => '参加活动',
    'Source 2' => '购买商品(待上线)',
    'Source 3' => '发布供需(待上线)'
];
