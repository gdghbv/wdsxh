<?php
// +----------------------------------------------------------------------
// | 麦沃德科技赋能开发者，助力商协会发展 
// +----------------------------------------------------------------------
// | Copyright (c) 2017～2024  www.wdsxh.cn    All rights reserved.
// +----------------------------------------------------------------------
// | 沃德商协会系统并不是自由软件，不加密，并不代表开源，未经许可不可自由转售和商用
// +----------------------------------------------------------------------
// | Author: MY WORLD Team <bd@maiwd.cn>   www.maiwd.cn
// +----------------------------------------------------------------------

return [
    'Name'          => '名称',
    'Member_id'     => '选择发布人',
    'Member_id -1'  => '平台',
    'Type'          => '类型',
    'Type 1'        => '自由接龙',
    'Type 2'        => '限定接龙',
    'Expire_time'   => '截止时间',
    'Member_ids'    => '选择会员',
    'Content'       => '接龙内容',
    'Createtime'    => '创建时间',
    'Updatetime'    => '更新时间',
    'Deletetime'    => '删除时间',
    'Weigh'         => '权重',
    'Status'        => '状态',
    'Status normal' => '显示',
    'Set status to normal'=> '设为显示',
    'Status hidden' => '隐藏',
    'Set status to hidden'=> '设为隐藏',
    'Page_view'     => '浏览量',
    'Are you sure you want to delete this item?'            => '警告：一旦删除，数据无法恢复，谨慎处理！！！',
    'Jielong_auth'               => '对外状态',
    'Jielong_auth 1'             => '对外开放',
    'Jielong_auth 2'             => '会员专属',
    'Applet_jielong_qrcode_path'             => '接龙小程序码',
];
