<?php

return [
    'Id'            => 'ID',
    'Page Name'     => '模板名称',
    'Status'        => '页面类型',
    'Status home'   => '首页',
    'Set status to home'=> '设为首页',
    'Status custom' => '自定义页',
    'Set status to custom'=> '设为自定义页',
    'Page_data'     => '页面数据',
    'Createtime'    => '创建时间',
    'Updatetime'    => '更新时间',
    'Deletetime'    => '删除时间',
    'Are you sure you want to delete this item?'            => '警告：一旦删除，数据无法恢复，谨慎处理！！！',
];
