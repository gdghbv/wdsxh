<?php

return [
    'Id'         => 'id',
    'Name'       => '快递公司全称',
    'Weigh'      => '权重',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Deletetime' => '删除时间',
    'Are you sure you want to delete this item?'            => '警告：一旦删除，数据无法恢复，谨慎处理！！！',
    'Brief_introduction'      => '快递公司英文简称',
];
