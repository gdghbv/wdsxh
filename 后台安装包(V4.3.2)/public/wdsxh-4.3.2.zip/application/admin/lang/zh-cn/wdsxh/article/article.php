<?php

return [
    'Id'            => 'ID',
    'Cat_id'        => '选择分类',
    'Type'          => '类型',
    'Type 1'        => '文本',
    'Type 2'        => '链接',
    'Commerce_name' => '商会名称',
    'Title'         => '文章标题',
    'Release'       => '发布人',
    'Image'         => '封面图片',
    'Content'       => '内容',
    'Status'        => '状态',
    'Status 0'      => '隐藏',
    'Set status to 0'=> '设为隐藏',
    'Status 1'      => '显示',
    'Set status to 1'=> '设为显示',
    'Weigh'         => '排序',
    'Createtime'    => '发布时间',
    'Read_num'      => '阅读数',
    'Are you sure you want to delete this item?'            => '警告：一旦删除，数据无法恢复，谨慎处理！！！',
];
