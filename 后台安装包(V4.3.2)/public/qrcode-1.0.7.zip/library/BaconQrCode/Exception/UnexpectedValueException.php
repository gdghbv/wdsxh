<?php
declare(strict_types = 1);

namespace BaconQrCode\Exception;

final class UnexpectedValueException extends \UnexpectedValueException implements ExceptionInterface
{
}
